
    // // JavaScript to handle the click event
    // document.body.addEventListener('click', function() {
    //   document.body.style.height = '100%';
    //   document.body.style.overflow = 'hidden';
    //   document.body.style.paddingRight = '0px';
    // });
